import java.util.Date;
import java.util.*;
/**
 * A fix-sized array of students
 * array length should always be equal to the number of stored elements
 * after the element was removed the size of the array should be equal to the number of stored elements
 * after the element was added the size of the array should be equal to the number of stored elements
 * null elements are not allowed to be stored in the array
 * 
 * You may add new methods, fields to this class, but DO NOT RENAME any given class, interface or method
 * DO NOT PUT any classes into packages
 *
 */
public class StudentGroup extends Student implements StudentArrayOperation {

	private Student[] students;
	int id;
	double marks;
	Date birthDate;
	String fullName;
	int i;
	/**
	 * DO NOT remove or change this constructor, it will be used during task check
	 * @param length
	 */
	public StudentGroup(int length) {
		this.students = new Student[length];
	}

	@Override
	public Student[] getStudents() {
		// Add your implementation here
		return students;
	}


	@Override
	public void setStudents(Student[] students) {
		// Add your implementation here
		if(students==null)	
		{
			throw new IllegalArguementException;
		}
		Scanner s=new Scanner(System.in);
		for(i=0;i<students.length;i++)
		{
			students[i].fullName=s.next();	
			students[i].id=s.nextInt();	
			students[i].birthDate=s.next();		
			students[i].avgMark=s.nextDouble();		
		}	
	}

	@Override
	public Student getStudent(int index) {
		// Add your implementation here
		
		return students[index];
	}

	@Override
	public void setStudent(Student student, int index) {
		// Add your implementation here
		if(students==null)	
		{
			throw new IllegalArguementException;
		}
		this.students[index]=student;
	}

	@Override
	public void addFirst(Student student) {
		// Add your implementation here
		for(int i=length;i>0;i--)
		{
			students[i+1]=student[i];

		}
		students[0]=student;
	

	}

	@Override
	public void addLast(Student student) {
		// Add your implementation here
		students[length+1]=student;
	}

	@Override
	public void add(Student student, int index) {
		// Add your implementation here
		students[index]=student;
	}

	@Override
	public void remove(int index) {
		// Add your implementation here
		student[index]=NULL;
	}


	@Override
	public void remove(Student student) {
		// Add your implementation here
		for(int j=0;j<length-1;j++)
		{
			if(studnets[j].id==student.id)
			{
				students[j]=NULL;
				break;
			}
		}
	}

	@Override
	public void removeFromIndex(int index) {
		// Add your implementation here
		for(int j=index+1;j<=length-1;j++)
		{
			student[j]=NULL;
		}
	}

	@Override
	public void removeFromElement(Student student) {
		// Add your implementation here
		for(int j=0;j<=length-1;j++)
		{
			if(studnets[j].id==student.id)
			{
				j++;
				while(j<length)
				{
					students[j]=NULL;
					j++;
				}
				
			}
		}
	
	}

	@Override
	public void removeToIndex(int index) {
		// Add your implementation here
		for(int j=0;j<index-1;j++)
		{
			students[j]=NULL;
		}
	}

	@Override
	public void removeToElement(Student student) {
		// Add your implementation here
		for(int j=0;j<=length-1;j++)
		{
			if(studnets[j].id==student.id)
				break;
			else
			{
				students[j]=NULL;
				
			}
		}

	}

	@Override
	public void bubbleSort() {
		// Add your implementation here
		Student temp=new Student;
		for(int i=0;i<length-1;i++)
		{
			for(int j=0;j<length-2;j++)
			{
				if(students[j].id>students[j+1].id)
				{
					temp=students[j];
					students[j]=students[j+1];
					students[j+1]=temp;
				}
			}
		}
	}

	@Override
	public Student[] getByBirthDate(Date date) {
		// Add your implementation here
		Student[] birth=new Studenr=t[length];
		int i=0;
		for(int j=0;j<length;j++)
		{
			if(students[j].birthDate==date)
			{
				birth[i]=student[j];
				i++;

			}
		}
		return birth;
	}

	@Override
	public Student[] getBetweenBirthDates(Date firstDate, Date lastDate) {
		// Add your implementation here
		Student[] births= new Student[length];
        int i=0;
        for(int j=0;j<length;j++)
        {
            if((students[j].birthDate>firstDate)&&(students[j].birthDate<lastDate)){
            	births[i]=students[j];
            	i++;
            }
        }
		return births;
	}

	@Override
	public Student[] getNearBirthDate(Date date, int days) {
		// Add your implementation here
		Student[] births= new Student[length];
        int i=0;
        for(int j=0;j<length;j++)
        {
            if((students[j].birthDate>firstDate)||(students[j].birthDate<firstDate+1)||(students[j].birthDate<firstDate-1)){
            	births[i]=students[j];
            	i++;
            }
        }
		return births;
	}

	@Override
	public int getCurrentAgeByDate(int indexOfStudent) {
		// Add your implementation here
		Student[] birth=new Studenr=t[length];
		int i=0,age;
		for(int j=0;j<length;j++)
		{
			if(students[j].birthDate==date)
			{
				birth[i]=student[j];
				i++;

			}
		}
		age=2017-birth;
		return age;
	}

	@Override
	public Student[] getStudentsByAge(int age) {
		// Add your implementation here
		if(age=students.age)
		{
			return students;
		}
		
	}

	@Override
	public Student[] getStudentsWithMaxAvgMark() {
		// Add your implementation here
		Student temp=new Student;
		for(int i=0;i<length-1;i++)
		{
			for(int j=0;j<length-2;j++)
			{
				if(students[j].avgMarks>students[j+1].avgMarks)
				{
					temp=students[j];
					students[j]=students[j+1];
					students[j+1]=temp;
				}
			}
		}

		return students;
	}

	@Override
	public Student getNextStudent(Student student) {
		// Add your implementation here
		int i=students[i];
		return students[i+1];
	}
}
